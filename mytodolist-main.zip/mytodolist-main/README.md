The final version of 'mytodolist' app! 

Link: https://heartfelt-piroshki-f5f85e.netlify.app
