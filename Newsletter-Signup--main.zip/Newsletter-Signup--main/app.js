//What needs to be installed on the server i.e., Git Bash - START
const express = require('express');
const bodyParser = require('body-parser');
const mailchimp = require("@mailchimp/mailchimp_marketing");
//END

//The app! - START
const app = express();
//END

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended: true}));

mailchimp.setConfig({
    apiKey:"b2ac0866bc34e406e4819c5dd1802c8a-us13",
    server:"us13"
});


// The file (/signup.html) that you send to '.get' the information from those signing up on the homepage ('/') - START
app.get("/", function(req, res){
  res.sendFile(__dirname + "/signup.html");
})
//END

//Express, the ('app'.) is instructed to 'post' the homepage('/') to whomever wants to sign up!-START
app.post("/", function(req, res){
//END

  const listId = "ad859f5279";
  const SubscribingUser = {
//The req in this project - START
    firstName: req.body.fName,
    lastName: req.body.lName,
    email: req.body.email
};
//END
async function run() {
  try {
  const response = await mailchimp.lists.addListMember(listId, {

    email_address: SubscribingUser.email,
    status: "subscribed",
    merge_fields: {
      FNAME: SubscribingUser.firstName,
      LNAME: SubscribingUser.lastName
    }
  });

  console.log("Successfully added contact as an audience member.");


    res.sendFile(__dirname + "/success.html");
} catch (e) {
    res.sendFile(__dirname + "/failure.html");
  }
}

  run();
})

app.post("/failure", function(req, res){
  res.redirect("/")
})

app.listen(process.env.PORT || 3000, function() {
  console.log("Server is running on Port 3001");
});