# IoChat
This is a project to test proficiency in TypeScript, NodeJS and Express: the IO Chat! 
